<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Withdraw</title>
  </head>
  <body>
    <h1 style="color:#02a95c;font-family:daggersquare;" align= "center">Money withdrawed successfully!</h1>
    
    <a href="investmentHistory.php">Go back</a>
    <p  align="right"><a href="dashbord.php">Dashbord</a>

  </body>
</html>