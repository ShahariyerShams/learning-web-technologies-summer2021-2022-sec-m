<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invest</title>
</head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>
    <h1 align= "center" color>
	<font face="daggersquare" color="#02a95c">Fund Lagbe!</font></h1>

    <body>
    <h1 align= "center">Hello Sir.Welcome to Fund Lagbe.</h1>
    

  </body>
	         <p><a href="aboutus.html">About Us</a></p>
             <p><a href="aboutus.html">Campaigns</a></p>
            <p align="right" ><a href="donationHistory.php">View Donation History</a></p>
            <p align="right" ><a href="investmentHistory.php">View Invesment History</a></p>
             